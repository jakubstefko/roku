Simple Roku Scene Graph channel containing an empty scene.  
This can be enhanced with the following features:

- Add grid with video preview (this adds the video grid)
- Add loading indicator component
